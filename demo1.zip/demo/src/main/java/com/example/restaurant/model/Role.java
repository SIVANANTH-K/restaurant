package com.example.restaurant.model;

public enum Role {
    ROLE_USER,
    ROLE_OWNER,
    ROLE_ADMIN
}
